/* ============================================================
   auth.js — авторизация и общие элементы шапки
   Подключается на всех страницах.
   ============================================================ */

// Защита страницы: если не вошёл — отправляем на главную
function requireAuth() {
  if (!getCurrentUser()) {
    window.location.href = 'index.html';
    return false;
  }
  return true;
}

/* ---------- Инициализация шапки ---------- */

function initHeader() {
  highlightActiveNav();
  renderUserChip();
  setupNavToggle();
  setupCurrencySwitch();
}

// Подсветка активного пункта меню по имени файла
function highlightActiveNav() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  const links = document.querySelectorAll('.main-nav a');
  links.forEach((link) => {
    const href = link.getAttribute('href');
    if (href === path) link.classList.add('active');
  });
}

// Имя пользователя и кнопка выхода в шапке
function renderUserChip() {
  const chip = document.getElementById('userChip');
  if (!chip) return;
  const user = getCurrentUser();
  if (!user) {
    chip.hidden = true;
    return;
  }
  chip.hidden = false;
  const nameEl = chip.querySelector('.uname');
  if (nameEl) nameEl.textContent = user.name;
  const logout = document.getElementById('logoutBtn');
  if (logout) {
    logout.addEventListener('click', function handleLogout() {
      clearSession();
      window.location.href = 'index.html';
    });
  }
}

// Бургер-меню на мобильных
function setupNavToggle() {
  const toggle = document.getElementById('navToggle');
  const nav = document.getElementById('mainNav');
  if (!toggle || !nav) return;
  toggle.addEventListener('click', function toggleNav() {
    nav.classList.toggle('open');
  });
}

/* ---------- Переключатель валюты ---------- */

function setupCurrencySwitch() {
  const wrap = document.getElementById('currencySwitch');
  if (!wrap) return;
  const user = getCurrentUser();
  if (!user) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  const current = getUserCurrency(user.id);

  wrap.innerHTML = Object.keys(CURRENCIES)
    .map(function buildButton(code) {
      const active = code === current ? ' active' : '';
      return '<button class="cur-btn' + active + '" data-cur="' + code + '">' +
        CURRENCIES[code].symbol + '</button>';
    })
    .join('');

  wrap.querySelectorAll('.cur-btn').forEach(function bind(button) {
    button.addEventListener('click', function onPick() {
      const code = button.getAttribute('data-cur');
      setUserCurrency(user.id, code);
      wrap.querySelectorAll('.cur-btn').forEach(function clear(b) { b.classList.remove('active'); });
      button.classList.add('active');
      // Сообщаем странице, что валюта изменилась — она перерисует суммы
      document.dispatchEvent(new CustomEvent('currencychange', { detail: { currency: code } }));
    });
  });
}

/* ---------- Регистрация и вход ---------- */

// Возвращает { ok: true, user } или { ok: false, message }
function registerUser(name, email, password) {
  const cleanName = String(name).trim();
  const cleanEmail = String(email).trim().toLowerCase();

  if (cleanName.length < 2) return { ok: false, message: 'Введите имя (минимум 2 символа).' };
  if (!isValidEmail(cleanEmail)) return { ok: false, message: 'Введите корректный email.' };
  if (String(password).length < 4) return { ok: false, message: 'Пароль должен быть минимум 4 символа.' };
  if (findUserByEmail(cleanEmail)) return { ok: false, message: 'Пользователь с таким email уже есть. Войдите.' };

  const user = {
    id: generateId(),
    name: cleanName,
    email: cleanEmail,
    password: String(password), // хранится локально в браузере, не для реальной защиты
    createdAt: Date.now(),
  };
  const users = getUsers();
  users.push(user);
  saveUsers(users);
  setSession(user.id);
  return { ok: true, user };
}

function loginUser(email, password) {
  const user = findUserByEmail(email);
  if (!user) return { ok: false, message: 'Пользователь не найден. Зарегистрируйтесь.' };
  if (user.password !== String(password)) return { ok: false, message: 'Неверный пароль.' };
  setSession(user.id);
  return { ok: true, user };
}
