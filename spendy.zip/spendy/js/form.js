/* ============================================================
   form.js — логика страницы добавления/редактирования (form.html)
   ============================================================ */

let editingId = null; // если задан — режим редактирования

document.addEventListener('DOMContentLoaded', function initForm() {
  initHeader();
  if (!requireAuth()) return;

  const user = getCurrentUser();
  populateCategories(user);
  updateCurrencyLabel(user);
  setupCustomCategory(user);

  // Дата по умолчанию — сегодня
  const dateInput = document.getElementById('fDate');
  dateInput.value = todayISO();

  // Режим редактирования из ?id=
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  if (id) loadForEdit(id, user);

  document.getElementById('saveBtn').addEventListener('click', function onSave() { saveExpense(user); });

  // Обновление символа валюты в поле суммы при переключении
  document.addEventListener('currencychange', function onCur() { updateCurrencyLabel(user); });
});

// Заполнить выпадающий список категорий (фикс + свои)
function populateCategories(user) {
  const select = document.getElementById('fCategory');
  const custom = getCustomCategories(user.id);
  const fixedOpts = FIXED_CATEGORIES.map(function build(c) {
    return '<option value="' + escapeHtml(c.name) + '">' + c.icon + ' ' + escapeHtml(c.name) + '</option>';
  }).join('');
  const customOpts = custom.length
    ? '<optgroup label="Мои категории">' + custom.map(function build(name) {
        return '<option value="' + escapeHtml(name) + '">🏷️ ' + escapeHtml(name) + '</option>';
      }).join('') + '</optgroup>'
    : '';
  select.innerHTML = fixedOpts + customOpts;
}

// Показать символ выбранной валюты рядом с суммой
function updateCurrencyLabel(user) {
  const label = document.getElementById('curLabel');
  if (label) label.textContent = CURRENCIES[getUserCurrency(user.id)].symbol;
}

// Добавление собственной категории
function setupCustomCategory(user) {
  const input = document.getElementById('newCategory');
  const button = document.getElementById('addCategoryBtn');
  if (!button) return;
  button.addEventListener('click', function add() {
    const name = input.value.trim();
    if (name.length < 2) {
      alert('Название категории слишком короткое.');
      return;
    }
    const exists = FIXED_CATEGORIES.some(function f(c) { return c.name.toLowerCase() === name.toLowerCase(); }) ||
      getCustomCategories(user.id).some(function c(n) { return n.toLowerCase() === name.toLowerCase(); });
    if (exists) {
      alert('Такая категория уже есть.');
      return;
    }
    addCustomCategory(user.id, name);
    populateCategories(user);
    document.getElementById('fCategory').value = name;
    input.value = '';
  });
}

// Загрузка данных в форму для редактирования
function loadForEdit(id, user) {
  const expense = getExpenseById(id);
  if (!expense || expense.userId !== user.id) return;
  editingId = id;
  document.getElementById('fTitle').value = expense.title;
  // Сумму показываем в текущей валюте пользователя
  const currency = getUserCurrency(user.id);
  document.getElementById('fAmount').value = Math.round(convertFromBase(expense.amount, currency) * 100) / 100;
  document.getElementById('fCategory').value = expense.category;
  document.getElementById('fDate').value = expense.date;
  document.getElementById('formTitle').textContent = 'Редактировать расход';
  document.getElementById('formSub').textContent = 'Измените данные и сохраните изменения.';
  document.getElementById('saveBtn').textContent = 'Сохранить изменения';
}

// Сохранение с ручной валидацией (не через required)
function saveExpense(user) {
  const title = document.getElementById('fTitle').value.trim();
  const amountRaw = document.getElementById('fAmount').value.trim();
  const category = document.getElementById('fCategory').value;
  const date = document.getElementById('fDate').value;

  // Проверки + alert при ошибке (требование ТЗ)
  if (title.length === 0) { alert('Введите название расхода.'); return; }
  if (amountRaw.length === 0) { alert('Введите сумму.'); return; }
  const amount = Number(amountRaw.replace(',', '.'));
  if (isNaN(amount) || amount <= 0) { alert('Сумма должна быть положительным числом.'); return; }
  if (!category) { alert('Выберите категорию.'); return; }
  if (!date) { alert('Укажите дату.'); return; }

  const currency = getUserCurrency(user.id);
  const baseAmount = convertToBase(amount, currency); // храним в тенге

  if (editingId) {
    const existing = getExpenseById(editingId);
    existing.title = title;
    existing.amount = baseAmount;
    existing.category = category;
    existing.date = date;
    upsertExpense(existing);
  } else {
    const expense = {
      id: generateId(),
      userId: user.id,
      title: title,
      amount: baseAmount,
      category: category,
      date: date,
      paid: false,
      createdAt: Date.now(),
    };
    upsertExpense(expense);
  }

  // Возврат на главную
  window.location.href = 'index.html';
}
