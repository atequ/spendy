/* ============================================================
   utils.js — вспомогательные функции и константы
   ============================================================ */

// Валюты. rate — сколько базовых единиц (тенге) в 1 единице валюты.
// Суммы хранятся в базовой валюте (KZT), а отображаются в выбранной.
const CURRENCIES = {
  KZT: { symbol: '₸', rate: 1 },
  USD: { symbol: '$', rate: 480 },
  RUB: { symbol: '₽', rate: 5.3 },
};

// Фиксированный список категорий: имя, иконка, цвет
const FIXED_CATEGORIES = [
  { name: 'Еда',          icon: '🍔', color: '#fb7185' },
  { name: 'Транспорт',    icon: '🚌', color: '#22d3ee' },
  { name: 'Жильё',        icon: '🏠', color: '#6366f1' },
  { name: 'Развлечения',  icon: '🎮', color: '#8b5cf6' },
  { name: 'Здоровье',     icon: '💊', color: '#34d399' },
  { name: 'Одежда',       icon: '👕', color: '#f472b6' },
  { name: 'Связь',        icon: '📱', color: '#60a5fa' },
  { name: 'Другое',       icon: '📦', color: '#fbbf24' },
];

// Палитра цветов для пользовательских категорий
const CUSTOM_COLORS = ['#a78bfa', '#2dd4bf', '#f59e0b', '#f87171', '#38bdf8', '#c084fc', '#4ade80'];

// Уникальный идентификатор
function generateId() {
  if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
  return 'id-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
}

// Перевод из базовой валюты (KZT) в выбранную
function convertFromBase(baseAmount, currency) {
  return baseAmount / CURRENCIES[currency].rate;
}

// Перевод из выбранной валюты в базовую (KZT) для хранения
function convertToBase(amount, currency) {
  return amount * CURRENCIES[currency].rate;
}

// Форматирование денег: число + символ валюты
function formatMoney(baseAmount, currency) {
  const value = convertFromBase(baseAmount, currency);
  const rounded = Math.round(value * 100) / 100;
  const text = rounded.toLocaleString('ru-RU', { maximumFractionDigits: 2 });
  return text + ' ' + CURRENCIES[currency].symbol;
}

// Короткий формат для подписей графика (тыс / млн)
function formatShort(baseAmount, currency) {
  const value = convertFromBase(baseAmount, currency);
  const symbol = CURRENCIES[currency].symbol;
  if (value >= 1000000) return (value / 1000000).toFixed(1) + 'M ' + symbol;
  if (value >= 1000) return (value / 1000).toFixed(1) + 'K ' + symbol;
  return Math.round(value) + ' ' + symbol;
}

// Дата в читаемый вид: «8 июн 2026»
const MONTHS_SHORT = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MONTHS_FULL = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const WEEKDAYS = ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];

function formatDate(isoDate) {
  const date = new Date(isoDate);
  return date.getDate() + ' ' + MONTHS_SHORT[date.getMonth()] + ' ' + date.getFullYear();
}

// Сегодняшняя дата в формате YYYY-MM-DD (для значения по умолчанию в форме)
function todayISO() {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  const local = new Date(now.getTime() - offset * 60000);
  return local.toISOString().slice(0, 10);
}

// Метаданные категории (иконка + цвет). Для своих категорий — цвет из палитры.
function getCategoryMeta(name, customCategories) {
  const fixed = FIXED_CATEGORIES.find((category) => category.name === name);
  if (fixed) return fixed;
  const list = customCategories || [];
  const index = list.indexOf(name);
  const color = CUSTOM_COLORS[(index >= 0 ? index : 0) % CUSTOM_COLORS.length];
  return { name, icon: '🏷️', color };
}

// Защита от вставки HTML в текстовые поля
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

// Проверка email простым шаблоном
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim());
}

// Приветствие по времени суток
function greetingByTime() {
  const hour = new Date().getHours();
  if (hour < 6) return 'Доброй ночи';
  if (hour < 12) return 'Доброе утро';
  if (hour < 18) return 'Добрый день';
  return 'Добрый вечер';
}
