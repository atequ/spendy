/* ============================================================
   storage.js — слой работы с localStorage
   Все данные хранятся как массивы объектов в localStorage.
   ============================================================ */

// Ключи хранилища
const STORAGE_KEYS = {
  users: 'spendy_users',
  session: 'spendy_session',
  expenses: 'spendy_expenses',
  categories: 'spendy_categories',
  settings: 'spendy_settings',
};

/* ---------- Базовые get / save ---------- */

// Прочитать значение по ключу (с запасным значением)
function getData(key, fallback) {
  const raw = localStorage.getItem(key);
  if (raw === null) return fallback;
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.warn('Не удалось разобрать данные для ключа', key, error);
    return fallback;
  }
}

// Сохранить значение по ключу
function saveData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ---------- Пользователи ---------- */

function getUsers() {
  return getData(STORAGE_KEYS.users, []);
}

function saveUsers(users) {
  saveData(STORAGE_KEYS.users, users);
}

function findUserByEmail(email) {
  const normalized = String(email).trim().toLowerCase();
  return getUsers().find((user) => user.email === normalized) || null;
}

/* ---------- Сессия (текущий вход) ---------- */

function setSession(userId) {
  saveData(STORAGE_KEYS.session, userId);
}

function getSessionId() {
  return getData(STORAGE_KEYS.session, null);
}

function clearSession() {
  localStorage.removeItem(STORAGE_KEYS.session);
}

// Текущий вошедший пользователь (или null)
function getCurrentUser() {
  const id = getSessionId();
  if (!id) return null;
  return getUsers().find((user) => user.id === id) || null;
}

/* ---------- Расходы ---------- */

function getAllExpenses() {
  return getData(STORAGE_KEYS.expenses, []);
}

function saveAllExpenses(expenses) {
  saveData(STORAGE_KEYS.expenses, expenses);
}

// Расходы только текущего пользователя
function getUserExpenses(userId) {
  return getAllExpenses().filter((item) => item.userId === userId);
}

// Добавить или обновить расход
function upsertExpense(expense) {
  const all = getAllExpenses();
  const index = all.findIndex((item) => item.id === expense.id);
  if (index === -1) {
    all.push(expense);
  } else {
    all[index] = expense;
  }
  saveAllExpenses(all);
}

function deleteExpense(id) {
  const all = getAllExpenses().filter((item) => item.id !== id);
  saveAllExpenses(all);
}

function getExpenseById(id) {
  return getAllExpenses().find((item) => item.id === id) || null;
}

/* ---------- Пользовательские категории ---------- */

// Возвращает массив строк — собственные категории пользователя
function getCustomCategories(userId) {
  const map = getData(STORAGE_KEYS.categories, {});
  return map[userId] || [];
}

function addCustomCategory(userId, name) {
  const map = getData(STORAGE_KEYS.categories, {});
  const list = map[userId] || [];
  if (!list.includes(name)) {
    list.push(name);
    map[userId] = list;
    saveData(STORAGE_KEYS.categories, map);
  }
}

/* ---------- Настройки (валюта на пользователя) ---------- */

function getUserCurrency(userId) {
  const map = getData(STORAGE_KEYS.settings, {});
  return (map[userId] && map[userId].currency) || 'KZT';
}

function setUserCurrency(userId, currency) {
  const map = getData(STORAGE_KEYS.settings, {});
  map[userId] = Object.assign({}, map[userId], { currency });
  saveData(STORAGE_KEYS.settings, map);
}
