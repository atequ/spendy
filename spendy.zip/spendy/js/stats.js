/* ============================================================
   stats.js — логика страницы статистики (stats.html)
   Анимированные графики с переключением периода.
   ============================================================ */

let currentPeriod = 'week';

document.addEventListener('DOMContentLoaded', function initStats() {
  initHeader();
  if (!requireAuth()) return;

  setupPeriodButtons();
  renderStats();

  document.addEventListener('currencychange', function onCur() { renderStats(); });
});

// Кнопки переключения периода
function setupPeriodButtons() {
  document.querySelectorAll('.period-bar button').forEach(function bind(button) {
    button.addEventListener('click', function pick() {
      document.querySelectorAll('.period-bar button').forEach(function clear(b) { b.classList.remove('active'); });
      button.classList.add('active');
      currentPeriod = button.getAttribute('data-period');
      renderStats();
    });
  });
}

// Диапазон дат для выбранного периода
function getRange(period) {
  const end = new Date();
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  if (period === 'day') { /* старт = сегодня 00:00 */ }
  else if (period === 'week') start.setDate(start.getDate() - 6);
  else if (period === 'month') start.setDate(start.getDate() - 29);
  else if (period === 'halfyear') start.setMonth(start.getMonth() - 5);
  else if (period === 'year') start.setMonth(start.getMonth() - 11);
  return { start, end };
}

// Расходы пользователя в пределах периода
function getRangeExpenses(period) {
  const user = getCurrentUser();
  const range = getRange(period);
  return getUserExpenses(user.id).filter(function inRange(item) {
    const date = new Date(item.date);
    return date >= range.start && date <= addDayEnd(range.end);
  });
}

function addDayEnd(date) {
  const copy = new Date(date);
  copy.setHours(23, 59, 59, 999);
  return copy;
}

/* ---------- Построение данных столбчатой диаграммы ---------- */

function buildBars(period) {
  const expenses = getRangeExpenses(period);

  // «День» — разбивка по категориям
  if (period === 'day') {
    const custom = getCustomCategories(getCurrentUser().id);
    const byCat = {};
    expenses.forEach(function add(item) { byCat[item.category] = (byCat[item.category] || 0) + item.amount; });
    return Object.keys(byCat).map(function map(name) {
      return { label: shortLabel(name), value: byCat[name], color: getCategoryMeta(name, custom).color };
    });
  }

  // Дневные корзины (неделя, месяц)
  if (period === 'week' || period === 'month') {
    const days = period === 'week' ? 7 : 30;
    const buckets = [];
    for (let i = days - 1; i >= 0; i--) {
      const day = new Date();
      day.setHours(0, 0, 0, 0);
      day.setDate(day.getDate() - i);
      const label = period === 'week'
        ? ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'][day.getDay()]
        : String(day.getDate());
      buckets.push({ key: day.toDateString(), label, value: 0, gradient: true });
    }
    expenses.forEach(function add(item) {
      const key = new Date(item.date).toDateString();
      const bucket = buckets.find(function f(b) { return b.key === key; });
      if (bucket) bucket.value += item.amount;
    });
    // Для месяца показываем подпись через одну, чтобы не было каши
    if (period === 'month') {
      buckets.forEach(function thin(b, i) { if (i % 5 !== 0 && i !== buckets.length - 1) b.label = ''; });
    }
    return buckets;
  }

  // Месячные корзины (6 / 12 месяцев)
  const months = period === 'halfyear' ? 6 : 12;
  const buckets = [];
  for (let i = months - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(1);
    date.setMonth(date.getMonth() - i);
    buckets.push({ key: date.getFullYear() + '-' + date.getMonth(), label: MONTHS_SHORT[date.getMonth()], value: 0, gradient: true });
  }
  expenses.forEach(function add(item) {
    const date = new Date(item.date);
    const key = date.getFullYear() + '-' + date.getMonth();
    const bucket = buckets.find(function f(b) { return b.key === key; });
    if (bucket) bucket.value += item.amount;
  });
  return buckets;
}

function shortLabel(text) {
  return text.length > 8 ? text.slice(0, 7) + '…' : text;
}

/* ---------- Отрисовка ---------- */

function renderStats() {
  const currency = getUserCurrency(getCurrentUser().id);
  renderStatCards(currency);
  renderBarChart(currency);
  renderDonutChart(currency);
}

// Карточки: всего за период, записей, средний расход
function renderStatCards(currency) {
  const expenses = getRangeExpenses(currentPeriod);
  const total = expenses.reduce(function sum(acc, item) { return acc + item.amount; }, 0);
  const avg = expenses.length ? total / expenses.length : 0;

  document.getElementById('sTotal').textContent = formatMoney(total, currency);
  document.getElementById('sCount').textContent = expenses.length;
  document.getElementById('sAvg').textContent = formatMoney(avg, currency);
  document.getElementById('sPeriodLabel').textContent = periodTitle(currentPeriod);
}

function periodTitle(period) {
  return {
    day: 'за сегодня', week: 'за неделю', month: 'за месяц',
    halfyear: 'за 6 месяцев', year: 'за 12 месяцев',
  }[period];
}

// Столбчатая диаграмма с анимацией роста
function renderBarChart(currency) {
  const chart = document.getElementById('barChart');
  const hint = document.getElementById('barHint');
  const bars = buildBars(currentPeriod);
  hint.textContent = currentPeriod === 'day' ? 'Сегодняшние траты по категориям' : 'Динамика трат по периодам';

  const hasData = bars.some(function f(b) { return b.value > 0; });
  if (!hasData) {
    chart.innerHTML = '<div class="empty" style="margin:auto"><span class="em">📊</span><h4>Нет данных</h4><p>За этот период трат не было.</p></div>';
    return;
  }

  const max = Math.max.apply(null, bars.map(function v(b) { return b.value; })) || 1;

  chart.innerHTML = bars.map(function build(bar) {
    const percent = (bar.value / max) * 100;
    const background = bar.gradient ? 'var(--grad-primary)' : bar.color;
    return '' +
      '<div class="bar-col">' +
        '<div class="bar-track">' +
          '<div class="bar" data-h="' + percent + '" style="background:' + background + '">' +
            '<span class="tip">' + formatShort(bar.value, currency) + '</span>' +
          '</div>' +
        '</div>' +
        '<div class="bar-label">' + escapeHtml(bar.label) + '</div>' +
      '</div>';
  }).join('');

  // Анимация: высота с 0 до целевой на следующем кадре
  requestAnimationFrame(function grow() {
    chart.querySelectorAll('.bar').forEach(function set(el) {
      el.style.height = el.getAttribute('data-h') + '%';
    });
  });
}

// Кольцевая диаграмма по категориям + легенда
function renderDonutChart(currency) {
  const expenses = getRangeExpenses(currentPeriod);
  const custom = getCustomCategories(getCurrentUser().id);
  const donut = document.getElementById('donut');
  const legend = document.getElementById('donutLegend');
  const center = document.getElementById('donutCenter');

  const byCat = {};
  expenses.forEach(function add(item) { byCat[item.category] = (byCat[item.category] || 0) + item.amount; });
  const total = expenses.reduce(function sum(acc, item) { return acc + item.amount; }, 0);

  const segments = Object.keys(byCat)
    .map(function map(name) { return { name, value: byCat[name], color: getCategoryMeta(name, custom).color }; })
    .sort(function byVal(a, b) { return b.value - a.value; });

  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const svgHost = document.getElementById('donutSvg');

  if (segments.length === 0) {
    svgHost.innerHTML = '';
    center.innerHTML = '<div class="dc-label">Нет данных</div>';
    legend.innerHTML = '';
    return;
  }

  let cumulative = 0;
  const circles = segments.map(function build(seg) {
    const fraction = seg.value / total;
    const length = fraction * circumference;
    const startAngle = cumulative * 360;
    cumulative += fraction;
    return '<circle class="donut-seg" cx="100" cy="100" r="' + radius + '" fill="none" ' +
      'stroke="' + seg.color + '" stroke-width="24" stroke-linecap="butt" ' +
      'stroke-dasharray="' + length + ' ' + circumference + '" ' +
      'stroke-dashoffset="' + length + '" ' +
      'transform="rotate(' + startAngle + ' 100 100)"></circle>';
  }).join('');

  svgHost.innerHTML = '<svg viewBox="0 0 200 200" width="200" height="200">' + circles + '</svg>';
  center.innerHTML = '<div class="dc-label">Всего</div><div class="dc-value">' + formatShort(total, currency) + '</div>';

  // Анимация заполнения сегментов
  requestAnimationFrame(function fill() {
    svgHost.querySelectorAll('.donut-seg').forEach(function set(el) { el.setAttribute('stroke-dashoffset', '0'); });
  });

  // Легенда
  legend.innerHTML = segments.map(function build(seg) {
    const percent = Math.round((seg.value / total) * 100);
    return '<div class="legend-item">' +
      '<span class="legend-dot" style="background:' + seg.color + '"></span>' +
      '<span class="lg-name">' + escapeHtml(seg.name) + ' · ' + percent + '%</span>' +
      '<span class="lg-val">' + formatMoney(seg.value, currency) + '</span>' +
    '</div>';
  }).join('');
}
