/* ============================================================
   main.js — логика главной страницы (index.html)
   Экран авторизации + дашборд со списком расходов.
   ============================================================ */

// Состояние фильтров списка
const listFilters = { search: '', category: 'all', status: 'all' };

document.addEventListener('DOMContentLoaded', function initIndex() {
  initHeader();
  if (getCurrentUser()) {
    showApp();
  } else {
    showAuth();
  }
  setupAuthForms();
  // Перерисовка сумм при смене валюты
  document.addEventListener('currencychange', function onCurrency() {
    if (getCurrentUser()) renderDashboard();
  });
});

/* ---------- Переключение экранов ---------- */

function showAuth() {
  document.getElementById('authScreen').hidden = false;
  document.getElementById('appShell').hidden = true;
}

function showApp() {
  document.getElementById('authScreen').hidden = true;
  document.getElementById('appShell').hidden = false;
  renderUserChip();
  setupCurrencySwitch();
  renderDashboard();
  setupListControls();
}

/* ---------- Формы входа и регистрации ---------- */

function setupAuthForms() {
  const tabs = document.querySelectorAll('.auth-tabs button');
  const forms = {
    login: document.getElementById('loginForm'),
    register: document.getElementById('registerForm'),
  };

  tabs.forEach(function bindTab(tab) {
    tab.addEventListener('click', function switchTab() {
      tabs.forEach(function clear(t) { t.classList.remove('active'); });
      tab.classList.add('active');
      const target = tab.getAttribute('data-tab');
      forms.login.classList.toggle('active', target === 'login');
      forms.register.classList.toggle('active', target === 'register');
      hideAuthMessage();
    });
  });

  document.getElementById('loginBtn').addEventListener('click', handleLogin);
  document.getElementById('registerBtn').addEventListener('click', handleRegister);

  // Enter в полях формы
  forms.login.addEventListener('keydown', function onKey(e) { if (e.key === 'Enter') handleLogin(); });
  forms.register.addEventListener('keydown', function onKey(e) { if (e.key === 'Enter') handleRegister(); });
}

function handleLogin() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  const result = loginUser(email, password);
  if (!result.ok) {
    showAuthMessage(result.message);
    return;
  }
  showApp();
}

function handleRegister() {
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  const result = registerUser(name, email, password);
  if (!result.ok) {
    showAuthMessage(result.message);
    return;
  }
  showApp();
}

function showAuthMessage(text) {
  const box = document.getElementById('authMsg');
  box.textContent = text;
  box.className = 'form-msg error';
}

function hideAuthMessage() {
  const box = document.getElementById('authMsg');
  box.className = 'form-msg';
}

/* ---------- Дашборд ---------- */

function renderDashboard() {
  const user = getCurrentUser();
  renderGreeting(user);
  renderSummary(user);
  renderCategoryFilter(user);
  renderExpenseList(user);
}

// Приветствие по имени
function renderGreeting(user) {
  const nameEl = document.getElementById('greetName');
  if (nameEl) nameEl.textContent = user.name;
  const hello = document.getElementById('greetHello');
  if (hello) hello.textContent = greetingByTime() + ', ';
  const dateEl = document.getElementById('greetDate');
  if (dateEl) {
    const now = new Date();
    dateEl.textContent = WEEKDAYS[now.getDay()] + ', ' + now.getDate() + ' ' +
      MONTHS_FULL[now.getMonth()].toLowerCase() + ' ' + now.getFullYear();
  }
}

// Сводные карточки: записей, потрачено всего, топ-категория
function renderSummary(user) {
  const expenses = getUserExpenses(user.id);
  const currency = getUserCurrency(user.id);

  document.getElementById('statCount').textContent = expenses.length;

  const total = expenses.reduce(function sum(acc, item) { return acc + item.amount; }, 0);
  document.getElementById('statTotal').textContent = formatMoney(total, currency);

  // Топ-категория по сумме
  const byCategory = {};
  expenses.forEach(function add(item) {
    byCategory[item.category] = (byCategory[item.category] || 0) + item.amount;
  });
  let topName = '—';
  let topValue = -1;
  Object.keys(byCategory).forEach(function check(name) {
    if (byCategory[name] > topValue) { topValue = byCategory[name]; topName = name; }
  });
  const topEl = document.getElementById('statTop');
  if (topName === '—') {
    topEl.textContent = '—';
  } else {
    const meta = getCategoryMeta(topName, getCustomCategories(user.id));
    topEl.textContent = meta.icon + ' ' + topName;
  }
}

// Наполнение выпадающего фильтра категорий
function renderCategoryFilter(user) {
  const select = document.getElementById('filterCategory');
  if (!select) return;
  const custom = getCustomCategories(user.id);
  const all = FIXED_CATEGORIES.map(function pick(c) { return c.name; }).concat(custom);
  select.innerHTML = '<option value="all">Все категории</option>' +
    all.map(function opt(name) { return '<option value="' + escapeHtml(name) + '">' + escapeHtml(name) + '</option>'; }).join('');
  select.value = listFilters.category;
}

// Управление поиском и фильтрами
function setupListControls() {
  const search = document.getElementById('searchInput');
  const category = document.getElementById('filterCategory');
  const status = document.getElementById('filterStatus');

  if (search) search.addEventListener('input', function onSearch() {
    listFilters.search = search.value.trim().toLowerCase();
    renderExpenseList(getCurrentUser());
  });
  if (category) category.addEventListener('change', function onCat() {
    listFilters.category = category.value;
    renderExpenseList(getCurrentUser());
  });
  if (status) status.addEventListener('change', function onStatus() {
    listFilters.status = status.value;
    renderExpenseList(getCurrentUser());
  });
}

// Применение фильтров к списку
function applyFilters(expenses) {
  return expenses.filter(function match(item) {
    if (listFilters.search && !item.title.toLowerCase().includes(listFilters.search)) return false;
    if (listFilters.category !== 'all' && item.category !== listFilters.category) return false;
    if (listFilters.status === 'paid' && !item.paid) return false;
    if (listFilters.status === 'unpaid' && item.paid) return false;
    return true;
  });
}

// Отрисовка списка карточек
function renderExpenseList(user) {
  const container = document.getElementById('expenseList');
  if (!container) return;
  const currency = getUserCurrency(user.id);
  const custom = getCustomCategories(user.id);

  let expenses = getUserExpenses(user.id);
  // Сортировка: сначала новые по дате
  expenses.sort(function byDate(a, b) { return new Date(b.date) - new Date(a.date); });
  const filtered = applyFilters(expenses);

  // Счётчик показывает количество с учётом фильтров
  document.getElementById('listCount').textContent = filtered.length;

  if (expenses.length === 0) {
    container.innerHTML = emptyState('💸', 'Пока нет расходов', 'Нажмите «Добавить расход», чтобы внести первую трату.');
    return;
  }
  if (filtered.length === 0) {
    container.innerHTML = emptyState('🔍', 'Ничего не найдено', 'Попробуйте изменить поиск или фильтры.');
    return;
  }

  container.innerHTML = filtered.map(function buildCard(item, index) {
    const meta = getCategoryMeta(item.category, custom);
    const paidClass = item.paid ? ' paid' : '';
    return '' +
      '<div class="expense' + paidClass + '" style="animation-delay:' + (index * 0.04) + 's">' +
        '<input type="checkbox" class="e-check" data-id="' + item.id + '"' + (item.paid ? ' checked' : '') + ' title="Отметить как оплачено">' +
        '<div class="e-icon" style="border-color:' + meta.color + '55">' + meta.icon + '</div>' +
        '<div class="e-main">' +
          '<div class="e-title">' + escapeHtml(item.title) + '</div>' +
          '<div class="e-meta">' +
            '<span class="e-cat" style="background:' + meta.color + '">' + escapeHtml(item.category) + '</span>' +
            '<span>' + formatDate(item.date) + '</span>' +
            (item.paid ? '<span style="color:var(--ok)">оплачено</span>' : '<span>запланировано</span>') +
          '</div>' +
        '</div>' +
        '<div class="e-amount">' + formatMoney(item.amount, currency) + '</div>' +
        '<div class="e-actions">' +
          '<a class="icon-btn" href="form.html?id=' + item.id + '" title="Редактировать">✏️</a>' +
          '<button class="icon-btn danger" data-del="' + item.id + '" title="Удалить">🗑️</button>' +
        '</div>' +
      '</div>';
  }).join('');

  bindCardEvents(user);
}

function emptyState(emoji, title, text) {
  return '<div class="empty"><span class="em">' + emoji + '</span><h4>' + title + '</h4><p>' + text + '</p></div>';
}

// Обработчики чекбоксов и кнопок удаления
function bindCardEvents(user) {
  document.querySelectorAll('.e-check').forEach(function bindCheck(box) {
    box.addEventListener('change', function toggle() {
      const id = box.getAttribute('data-id');
      const expense = getExpenseById(id);
      if (!expense) return;
      expense.paid = box.checked;
      upsertExpense(expense);
      renderSummary(user);
      renderExpenseList(user);
    });
  });

  document.querySelectorAll('[data-del]').forEach(function bindDelete(button) {
    button.addEventListener('click', function remove() {
      const id = button.getAttribute('data-del');
      const expense = getExpenseById(id);
      const name = expense ? expense.title : 'эту запись';
      // Подтверждение через confirm (требование ТЗ)
      if (confirm('Удалить «' + name + '»? Действие нельзя отменить.')) {
        deleteExpense(id);
        renderSummary(user);
        renderExpenseList(user);
      }
    });
  });
}
